module.exports = {
	projects: [
		'<rootDir>tests/e2e/*',
		'<rootDir>lib/Migration/js/*',
	],
};
