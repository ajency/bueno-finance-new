/**
 * Component deprecations.
 */

/**
 * Version 1.8.1.
 */
import Save_1_8_1 from './components/save';
import attributes from './attributes';

export default {
		attributes,
		save: Save_1_8_1,
}
