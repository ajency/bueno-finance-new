<?php
/**
 * Shh... I'm sleeping here.
 *
 * Just an empty file.
 *
 * @package kraftbj/genesis-enews-extended.
 */

// Silence.
