<?php
/**
 * Genesis eNews Extended
 *
 * @package   BJGK\Genesis_enews_extended
 * @version   2.2.0
 * @author    Brandon Kraft <public@brandonkraft.com>
 * @link      https://kraft.blog/genesis-enews-extended/
 * @copyright Copyright (c) 2012-2018, Brandon Kraft
 * @license   GPL-2.0+
 */

/* Shh... I'm sleeping here. */
